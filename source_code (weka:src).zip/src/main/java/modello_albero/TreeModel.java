package modello_albero;

import java.util.ArrayList;
import java.util.List;

public class TreeModel {
	private int fatherIndex;
	private int nodeIndex;
	private List<TreeModel> childrenList;
	private boolean isLeaf;
	private int depth;
	
	
	public TreeModel(int selfIndex, int father, List<TreeModel> children){
		fatherIndex = father;
		childrenList = children;
		nodeIndex = selfIndex;
	}
	
	
	public TreeModel(int selfIndex, int father){
		fatherIndex = father;
		childrenList = new ArrayList<TreeModel>();
		nodeIndex = selfIndex;
	}
	
	
	public TreeModel(){
		fatherIndex = -1;
		nodeIndex = -1;
		childrenList = new ArrayList<TreeModel>();
	}
	
	
	public int getFather(){
		return fatherIndex;
	}
	
	
	public boolean getIsLeaf(){
		return isLeaf;
	}
	
	
	public List<TreeModel> getChildren(){
		return childrenList;
	}
	
	
	public int getSelfIndex(){
		return nodeIndex;
	}
	
	
	public void setFather(int father){
		fatherIndex = father;
	}
	
	
	public void setIsLeaf(boolean leaf){
		isLeaf = leaf;
	}
	
	public void setDepth(int d){
		depth = d;
	}
	
	public int getDepth(){
		return depth;
	}
	
	
	public void setChildren(List<TreeModel> children){
		childrenList = children;
	}	
	
	
	public void addChildren(TreeModel child){
		childrenList.add(child);
	}	
	
	
	public void setSelfIndex(int index){
		nodeIndex = index;
	}
	

	public String toString(){
		String childrenString = "";
		for(TreeModel child: childrenList){
			childrenString = childrenString + child.toString();
		}		
		return "["+nodeIndex+"]"+":("+childrenString+")";
	}
	
	
}
