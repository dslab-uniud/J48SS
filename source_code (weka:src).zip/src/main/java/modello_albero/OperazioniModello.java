package modello_albero;


import weka.core.Instances;
import weka.core.SerializationHelper;
import weka.core.converters.ConverterUtils.DataSource;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


import weka.classifiers.evaluation.Evaluation;
import weka.classifiers.trees.J48_editable;

public class OperazioniModello {
	
	public static void main(String args[]){
		
		J48_editable treeClassifier;
		DataSource source;
		Instances data;
		
		try{
			
			//Carico il dateset ed il modello salvato in precedenza
			treeClassifier = (J48_editable) SerializationHelper.read(new FileInputStream("/Users/andreabrunello/Dropbox/PhD Andrea - mio/Sviluppo Weka/J48_editable_soybean.model"));
			source = new DataSource("/Users/andreabrunello/Dropbox/PhD Andrea - mio/Sviluppo Weka/weka-3-9-1/data/soybean.arff");
			data = source.getDataSet();
			data.setClassIndex(data.numAttributes() - 1);		
						
			//Stampo delle statistiche sulla forma del modello
			System.out.println("Numero di nodi dell'albero:"+treeClassifier.measureTreeSize());
			System.out.println("Numero di foglie dell'albero:"+treeClassifier.measureNumLeaves());
			
			//Applico il modello sul dataset
			Evaluation eval = new Evaluation(data);
			eval.evaluateModel(treeClassifier, data);
			System.out.println(treeClassifier.toString());
			System.out.println(eval.toSummaryString());
			double accuracy = 1-eval.errorRate();
			System.out.println("Valore di accuracy:"+accuracy);
			
			
			//Now trying to delete some subtrees from the original one...
			System.out.println("------------ Ora vediamo l'albero potato -----------");				
			
			//Copy of the model, which will be pruned according to pruned_tree_repr
			J48_editable copyOfTreeModel = (J48_editable) weka.classifiers.trees.J48_editable.makeCopy(treeClassifier);		
			
			//Get the boolean array representation of the original tree
			boolean[] original_tree_repr = getGeneRepresentation(treeClassifier);
			TreeModel original_tree_model = new TreeModel();
			treeClassifier.getTreeModel(original_tree_model);
			//Thanks to the following array, given the index of a node (assigned in pre-order fashion),
			//I can jump to its position in the TreeMode, and from there I can follow the parent or children chains.
			//This is useful for the implementation of the mutation operator, where I must preserve the gene coherence
			//when i flip a value from 0 to 1 or from 1 to 0.
			TreeModel[] nodePointerArray = new TreeModel[(int) treeClassifier.measureTreeSize()];		
			populateNodePointerArray(original_tree_model,nodePointerArray);		
			
			//System.out.println(original_tree_model.toString());
						
			System.out.println("Initial tree representation:" + Arrays.toString(original_tree_repr));
			
			//The boolean array tracks for each node of the tree, represented in a pre-order fashion,
			//whether to keep the subtree rooted on it or not.
			boolean[] pruned_tree_repr = original_tree_repr.clone();
			pruned_tree_repr[1] = false;
			pruned_tree_repr[7] = false;
			pruned_tree_repr[8] = false;
			pruned_tree_repr[30] = false;
			pruned_tree_repr[32] = false;
			
			//Comparing the representation of pruned tree with the representation of the original one, 
			//determine which subtrees you need to prune in order to obtain the pruned tree
			List<Integer> subtreesToPrune = getSubtreesToPrune(original_tree_repr,pruned_tree_repr);
			
			//Delete subtrees which should be pruned according to the comparison above
			copyOfTreeModel.deleteGenericSubTrees(subtreesToPrune);
				
			System.out.println("Numero di nodi dell'albero:"+copyOfTreeModel.measureTreeSize());
			System.out.println("Numero di foglie dell'albero:"+copyOfTreeModel.measureNumLeaves());
			
			Evaluation eval2 = new Evaluation(data);
			eval2.evaluateModel(copyOfTreeModel, data);
			System.out.println(copyOfTreeModel.toString());
			System.out.println(eval2.toSummaryString());
			double accuracy2 = 1-eval2.errorRate();
			System.out.println("Valore di accuracy:"+accuracy2);	
			
	
			

		}catch(Exception e){
			System.out.println("E' successo qualche casino!");
			System.out.println(e);
			System.exit(1);
		}
		
		
		System.out.println("Finito!");
		
	}
	
	
	
	public static List<Integer> getSubtreesToPrune(boolean[] unprunedTree, boolean[] prunedTree){
		List<Integer> subtrees = new ArrayList<Integer>();	
		for(int i=0; i<unprunedTree.length; i++){
			if(unprunedTree[i] && !prunedTree[i]){
				subtrees.add(i);
			}
		}		
		return subtrees;
	}
	
	//Given a tree, returns its representation as a boolean vector
	//Nodes are considered in pre-order  format
	//TRUE means that the subtree rooted at the node is present
	public static boolean[] getGeneRepresentation(J48_editable decisionTree){
		List<Boolean> reprList = new ArrayList<Boolean>();
		decisionTree.treeGeneRepresentation(reprList);
		boolean[] array_tree_repr = new boolean[reprList.size()];
		Iterator<Boolean> iter = reprList.iterator();
		for(int i=0; i<reprList.size(); i++){
			array_tree_repr[i] = iter.next();
		}
		return array_tree_repr;
	}
	
	//It populates the array nodePointerArray, which has length equal to the number of nodes in the tree
	//For each cell, the array holds a pointer to the corresponding node in the TreeModel
	public static void populateNodePointerArray(TreeModel treem, TreeModel[] nodePointerArray){
		nodePointerArray[treem.getSelfIndex()] = treem;
		if(!treem.getIsLeaf()){
			for(TreeModel childtreem: treem.getChildren()){
				populateNodePointerArray(childtreem,nodePointerArray);
			}
		}			
	}


}
