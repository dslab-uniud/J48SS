package spmfClasses;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import spmfClasses.Itemset;
import spmfClasses.MemoryLogger;

/**
 * *
 * This is an implementation of the VGEN algorithm.
 * <br/><br/>
 * 
 * Copyright (c) 2014 Philippe Fournier-Viger, Antonio Gomariz
 * <br/><br/>
 * 
 * This file is part of the SPMF DATA MINING SOFTWARE
 * (http://www.philippe-fournier-viger.com/spmf).
 * <br/><br/>
 * 
 * SPMF is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * <br/><br/>
 * 
 * SPMF is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 * <br/><br/>
 * 
 * You should have received a copy of the GNU General Public License along with
 * SPMF. If not, see <http://www.gnu.org/licenses/>.
 * 
 * @see Bitmap
*  @see PrefixVGEN
*  @see PatternVGEN
*  @author Philippe Fournier-Viger  & Antonio Gomariz
 */
public class AlgoVGEN_versione_DT_keep_all_sizes {

	/** for statistics */
    public long startTime;
    public long endTime;
    public int patternCount;
    
    //Added here in our version of the code, horizontal DB
    // structure to store the horizontal database
    List<int[]> inMemoryDB;
    
    /**  minsup */
    private int minsup = 0;
    
    /** object to write to a file */
    //BufferedWriter writer = null;
    
    /** Vertical database */
    Map<Integer, Bitmap> verticalDB = new HashMap<Integer, Bitmap>();
    
    /** List indicating the number of bits per sequence */
    List<Integer> sequencesSize = null;
    
    /** the last bit position that is used in bitmaps */
    int lastBitIndex = 0;  
    
    /** maximum pattern length in terms of item count */
    private int maximumPatternLength = Integer.MAX_VALUE;
    
    /** Map: key: item   value:  another item that followed the first item + support
    * (could be replaced with a triangular matrix...) */
    Map<Integer, Map<Integer, Integer>> coocMapAfter = null;
    Map<Integer, Map<Integer, Integer>> coocMapEquals = null;
    
    /** Map indicating for each item, the smallest tid containing this item in a sequence. */
    boolean useCMAPPruning = true;
    
    //  =========  VARIABLES THAT ARE SPECIFIC TO VGEN ===================
    /** GENERATOR PATTERNS -  The list contains patterns of size k at position k in the list.
    * A map has the sum of sids as key and lists of patterns as value. */
    List<Map<Integer, List<PatternVGEN>>> generatorPatterns = null; 
    
    /** activate the backward checking strategy */
	private boolean useImmediateBackwardChecking = true;
	
	/** activate the backward pruning strategy */
	// DI DEFAULT IL BACKWARD PRUNING ERA MESSO A FALSE... PERCHE'?
	private boolean useBackwardPruning = true;
	
	/** if enabled, the result will be verified to see if some patterns found are not generators. */
	boolean DEBUG_MODE = false;  	
	
    /** the number of transaction in the database (to calculate the support of the empty set) */
    int transactionCount = 0;
    
    
    //  =========  VARIABLES THAT HAVE BEEN ADDED IN OUR ALGORITHM ADAPTATION  ===================
    /** Information gain of the best pattern found so far by the algorithm.
     *  The value is for each of the one-vs-all problems, classes ordered as in the array "classes" */
    double[] bestIG;
    // The hashmap keeps track of the best pattern IG for each of the explored pattern lengths (in number of items)
    // They key is made as: pattern_length;pattern_index
    HashMap<String,Double> bestIGforLength = new HashMap<String,Double>();
    /** Best pattern found so far by the algorithm, according to the information gain score. 
     *  The value is for each of the one-vs-all problems, classes ordered as in the array "classes" */
    //String[] bestPattern;  
    // The hashmap keeps track of the best pattern for each of the explored pattern lengths (in number of items)
    // They key is made as: pattern_length;pattern_index
    HashMap<String,String> bestPatternforLength = new HashMap<String,String>();
    //Bitmap bestPatternPrefixBitmap[];
    // The hashmap keeps track of the best pattern bitmap for each of the explored pattern lengths (in number of items)
    // They key is made as: pattern_length;pattern_index
    HashMap<String,Bitmap> bestPatternPrefixBitmapforLength = new HashMap<String,Bitmap>();
    
    // Keeps track of the greatest pattern length found so far
    int longestPatternLength = -1;
    
    // Weight used in the weighted sum, between 0 and 1: the larger the weight, the longer the pattern
    double weight;
    
    /** Lowest support of a pattern found so far*/
    double lowestSupport = 0.0;   
    /** Pattern having the lowest support found so far. */
    String lowestSupPattern = "";   
    /** Initial entropy of the dataset
     *  The value is for each of the one-vs-all problems, classes ordered as in the array "classes" */
    double[] initialEntropy;
    double initialEntropyMulticlass = 1.0;
    /**Keeps track of the class of each of the instances, which are considered in the same order as in "inMemoryDB"*/
    List<String> instClasses;
    /**Keeps track of the class frequencies in the dataset*/
    HashMap<String,Double> classFreqs = new HashMap<String,Double>();
    /**Keeps track of the classes in the dataset, used to always follow the same ordering*/
    String[] classes;
    
    long totalTimeIGUB = 0;
    long totalTimeIGCALC = 0;
    long totalSubTimeIGCALC = 0;
    
    // ADDED IN OUR VERSION OF THE CODE
    long maxElapsedTime = -1;
    
    //=========  END OF VARIABLES THAT ARE SPECIFIC TO VGEN ===================
    
	/** the max gap between two itemsets of a pattern. It is an optional parameter that the user can set. */
	private int maxGap = Integer.MAX_VALUE;
	
	/** Optional parameter to decide whether sequence identifiers should be shown in the output for each pattern found */
	private boolean outputSequenceIdentifiers;
	
    /**
     * Default constructor
     */
    public AlgoVGEN_versione_DT_keep_all_sizes(List<int[]> horizontalDatabase, List<String> classesOfInstances, long maxTime, double weightIn) {
    	// Copy the horizontal database, which is passed as input
    	inMemoryDB = new ArrayList<int[]>(horizontalDatabase);
    	instClasses = new ArrayList<String>(classesOfInstances);
    	maxElapsedTime = maxTime;
    	weight = weightIn;
    	/*
    	if(inMemoryDB.size() == 33){
    		System.out.println("Sequenze");
    		for(int[] seq : horizontalDatabase){
    			System.out.println(Arrays.toString(seq));
    		}
    		System.out.println("Classi");
    		System.out.println(Arrays.toString(classesOfInstances.toArray()));
    	}
    	*/
    }

    /**
     * Method to run the algorithm
     *
     * @param input path to an input file
     * @param outputFilePath path for writing the output file
     * @param minsupRel the minimum support as a relative value
     * @return 
     * @throws IOException exception if error while writing the file or reading
     */
    public Map<String, String> runAlgorithm(double[] maxIGfound, double minsupRel) throws IOException {
        // (THE OUTPUT IS A MAP):
    	//	"pattern" 		-> 		string of the pattern
    	// 	"IG"			-> 		information gain of the pattern
    	//	"inst_indexes"	-> 		indexes of the instances satisfying the pattern
    	if(DEBUG_MODE){
    		System.out.println(" %%%%%%%%%%  DEBUG MODE %%%%%%%%%%");
    	}
    	
    	//System.out.println("Cutoff: " + maxElapsedTime);
    	   	
        Bitmap.INTERSECTION_COUNT = 0;
        // create an object to write the file
        //writer = new BufferedWriter(new FileWriter(outputFilePath));
        // initialize the number of patterns found
        patternCount = 0;
        // to log the memory used
        MemoryLogger.getInstance().reset();

        // record start time
        startTime = System.currentTimeMillis();
        // RUN THE ALGORITHM
        vgen(maxIGfound, minsupRel);
        // record end time
        endTime = System.currentTimeMillis();
        
        //writeResultTofile(outputFilePath);
        
        // close the file
        //writer.close();
        
        //System.out.println("sono uscito da vgen()");
        
        // ################################## FOR DEBUGGGING #############################
        // ########  THIS CODE CHECK IF A PATTERN FOUND IS NOT A GENERATOR ##############
        if(DEBUG_MODE) {
        	System.out.println("minsup absolute : " + minsup);
        	
        	List<PatternVGEN> listPatterns = new ArrayList<PatternVGEN>();
        	for(Map<Integer, List<PatternVGEN>> mapSizeI : generatorPatterns) {
	        	if(mapSizeI == null) {
	        		continue;
	        	}
	        	for(List<PatternVGEN> listpattern : mapSizeI.values()) {
//	        		System.out.println(" " + pat.prefix  + "    sup: " + pat.getSupport());
	        		for(PatternVGEN pat : listpattern) {
	        			listPatterns.add(pat);
	        		}
	        	}
	        }
        	// CHECK IF SOME PATTERNS ARE NOTE GENERATORS
        	for(PatternVGEN pat1 : listPatterns) {
        		// if this pattern is not the empty set and the support is same as empty set, then it is not a generator
        		if(pat1.prefix.size() > 0 && pat1.getAbsoluteSupport() == transactionCount) {
        			System.out.println("NOT A GENERATOR !!!!!!!!!  "  + pat1.prefix + "    sup: " + pat1.bitmap.getSupport() + " because of empty set");
        		}
        		
        		// otherwise we have to compare with every other patterns.
        		for(PatternVGEN pat2 : listPatterns) {
            		if(pat1 == pat2) {
            			continue;
            		}
            		
            		if(pat1.getAbsoluteSupport() == pat2.getAbsoluteSupport()) {
            			if(strictlyContains(pat1.prefix, pat2.prefix)) {
            				System.out.println("NOT A GENERATOR !!!!!!!!!  "  + pat1.prefix + " " + pat2.prefix + "   sup: " + pat1.bitmap.getSupport());
                			System.out.println(pat1.bitmap.sidsum + " " +  pat2.bitmap.sidsum);
            			}
            		}
            	}
        	}
        }
        // ############################ END OF DEBUGGING CODE ################################
        
        HashMap<Integer,Double> bestOverallIGforLength = new HashMap<Integer,Double>();
        HashMap<Integer,Integer> bestPatternIndexforLength = new HashMap<Integer,Integer>();
        //int bestPatternIndex = -1;  
        double bestIGfound = -1;
        for (String key : bestIGforLength.keySet()) {
        	if(bestIGforLength.get(key) > bestIGfound){
        		bestIGfound = bestIGforLength.get(key);
        	}
        	//System.out.println("STAMPA IG: " + bestIGforLength.get(key));
        	// They key is made as: pattern_length;pattern_index
        	String[] splittedKey = key.split(";");
        	//System.out.println("key: " + key + " splitted: "  + Arrays.toString(splittedKey));
        	int classIndex = Integer.parseInt(splittedKey[1]);
        	int patternLength = Integer.parseInt(splittedKey[0]);
        	double patternOverallIG = getPatternInfoGain(bestPatternPrefixBitmapforLength.get(key));
        	if(bestOverallIGforLength.get(patternLength) == null|| patternOverallIG > bestOverallIGforLength.get(patternLength)){
        		bestOverallIGforLength.put(patternLength, patternOverallIG);
        		bestPatternIndexforLength.put(patternLength, classIndex);
        	}
        }
        
        if(bestIGfound <= 0){
        	bestIGfound = 1; // it does not change anything in such case, but it avoids division by zero
        }
        
        //System.out.println("ho creato le hashmap");
        
        /*
        double bestOverallIG = 0.0;
        int bestPatternIndex = -1;
        for(int i=0; i<classes.length; i++){
        	if(bestPatternPrefixBitmap[i] != null){
	        	double patternOverallIG = getPatternInfoGain(bestPatternPrefixBitmap[i]);
	        	if(patternOverallIG > bestOverallIG){
	        		bestOverallIG = patternOverallIG;
	        		bestPatternIndex = i;
	        	}
        	}
        }
        */
        
        Map<String,String> result = new HashMap<String,String>();
    	//	"pattern" 		-> 		string of the pattern
    	// 	"IG"			-> 		information gain of the pattern
    	//	"inst_indexes"	-> 		indexes of the instances satisfying the pattern
        if(bestPatternIndexforLength.size() > 0){
        	// Determine the best pattern, according to the following weighted sum, to be minimized
        	// [ (weight)*(1-patternIG) + (1-weight)*(relativePatternLength) ]
        	// The larger the weight, the longer the pattern
        	// If two patterns have the same weight, then the shorter one is returned
        	int bestPatternLength = -1;
        	double bestPatternWeight = Double.MAX_VALUE;
        	
        	
        	Set<Integer> hashMapKeySet = bestPatternIndexforLength.keySet();
        	Integer[] hashMapKeySetArray = hashMapKeySet.toArray(new Integer[hashMapKeySet.size()]);
        	Arrays.sort(hashMapKeySetArray);
        	
        	//System.out.println("hashmapkeysetarray: " + Arrays.toString(hashMapKeySetArray));
        	
        	for(int patternLength : hashMapKeySetArray){
        		
        		//System.out.println("For index: " + patternLength)
        		
        		//System.out.println("IG: " + bestOverallIGforLength.get(patternLength));
        		//System.out.println("max IG: " + bestIGfound);
        		//System.out.println("IG rel: " + (bestOverallIGforLength.get(patternLength)/(double) bestIGfound));
        		
        		double weightedSum = (weight)*(1-(bestOverallIGforLength.get(patternLength)/(double) bestIGfound)) + (1-weight)*(patternLength/(double) longestPatternLength);
        		if(weightedSum < bestPatternWeight){
        			bestPatternWeight = weightedSum;
        			bestPatternLength = patternLength;
        		}
        	}
        	
        	//System.out.println("ho finito il for");
        	
        	
	        result.put("pattern", bestPatternforLength.get(bestPatternLength+";"+bestPatternIndexforLength.get(bestPatternLength)));
	        result.put("IG", bestOverallIGforLength.get(bestPatternLength)+"");
	        result.put("inst_indexes", bestPatternPrefixBitmapforLength.get(bestPatternLength+";"+bestPatternIndexforLength.get(bestPatternLength)).getSIDs(sequencesSize));
        }else{
	        result.put("pattern", "NO_USEFUL_DISCRIMINATIVE_PATTERNS_FOUND_WITHIN_SUPPORT");
	        result.put("IG", -1.0+"");
	        result.put("inst_indexes", "UNDEF");       	
        }        
        
        /*
        if(bestPatternIndex != -1){
	        result.put("pattern", bestPattern[bestPatternIndex]);
	        result.put("IG", bestOverallIG+"");
	        result.put("inst_indexes", bestPatternPrefixBitmap[bestPatternIndex].getSIDs(sequencesSize));
        }else{
	        result.put("pattern", "NO_USEFUL_DISCRIMINATIVE_PATTERNS_FOUND_WITHIN_SUPPORT");
	        result.put("IG", -1.0+"");
	        result.put("inst_indexes", "UNDEF");       	
        }
        */
        
        //System.out.println("sto per ritornare il risultato");
        
        return result;
        
        //return generatorPatterns;
    }

    /**
     * This is the main method for the VGEN algorithm
     *
     * @param an input file
     * @param minsupRel the minimum support as a relative value
     * @throws IOException
     */
    private void vgen(double[] maxIGfoundOneVsAllProbs, double minsupRel) throws IOException {
    	// create maxPattern array
    	generatorPatterns = new ArrayList<Map<Integer, List<PatternVGEN>>>(20);
        generatorPatterns.add(new HashMap<Integer, List<PatternVGEN>>());
        generatorPatterns.add(new HashMap<Integer, List<PatternVGEN>>());
        
        // the structure to store the vertical database
        // key: an item    value : bitmap
        verticalDB = new HashMap<Integer, Bitmap>();

                
        // STEP 0: SCAN THE DATABASE TO STORE THE FIRST BIT POSITION OF EACH SEQUENCE 
        // AND CALCULATE THE TOTAL NUMBER OF BIT FOR EACH BITMAP
        sequencesSize = new ArrayList<Integer>();
        lastBitIndex = 0; // variable to record the last bit position that we will use in bitmaps
        
        try {
            int bitIndex = 0;
            
            // for each line (sequence) from the input file
            Iterator<int[]> seqsIterator = inMemoryDB.iterator();
            
            while (seqsIterator.hasNext()) {
            	int[] tokens = seqsIterator.next();

                // record the length of the current sequence (for optimizations)
                sequencesSize.add(bitIndex);
                // split the sequence according to spaces into tokens
                //int[] transactionArray = new int[tokens.length];
                //inMemoryDB.add(transactionArray);

                for (int i = 0; i < tokens.length; i++) {
                    int item = tokens[i];
                    //transactionArray[i] = item;
                    // if it is not an itemset separator
                    if (item == -1) { // indicate the end of an itemset
                        // increase the number of bits that we will need for each bitmap
                        bitIndex++;
                    }
                }
            }
            // record the last bit position for the bitmaps
            lastBitIndex = bitIndex - 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        
        // Calculate the absolute minimum support 
        // by multipling the percentage with the number of
        // sequences in this database
        minsup = (int) Math.ceil(minsupRel * sequencesSize.size());
        if (minsup == 0) {
            minsup = 1;
        }
        
        // variable to count the number of transactions
    	transactionCount = 0;
    	
    	
    	// ADDED IN OUR VERSION OF THE CODE: WE KEEP TRACK OF THE CLASS FOR EACH OF THE INSTANCES 
    	// Initialization of the array
    	//System.out.println("minsup absolute ; relative : " + minsup + " ; " + minsupRel);
    	System.out.println("Instances in the dataset: "+ sequencesSize.size());

    	

        // STEP1: SCAN THE DATABASE TO CREATE THE BITMAP VERTICAL DATABASE REPRESENTATION
        try {
            //FileInputStream fin = new FileInputStream(new File(input));
            //BufferedReader reader = new BufferedReader(new InputStreamReader(fin));
            int[] thisLine;
            int sid = 0; // to know which sequence we are scanning
            int tid = 0;  // to know which itemset we are scanning

            // for each line (sequence) from the input file
            Iterator<int[]> seqsIterator = inMemoryDB.iterator();
            
            //System.out.println("nodo con numero istanze: " + inMemoryDB.size());
            while (seqsIterator.hasNext()) {
            	thisLine = seqsIterator.next();
            	/*
            	if(inMemoryDB.size() == 96){
            		System.out.println(Arrays.toString(thisLine));
            	}
            	*/

                // split the sequence according to spaces into tokens
                for (int token : thisLine) {
                    if (token == -1) { // indicate the end of an itemset
                        tid++;
                    } else if (token == -2) { // indicate the end of a sequence
//						determineSection(bitindex - previousBitIndex);  // register the sequence length for the bitmap
                        sid++;
                        tid = 0;
                    } else {  // indicate an item
                        // Get the bitmap for this item. If none, create one.
                        Bitmap bitmapItem = verticalDB.get(token);
                        if (bitmapItem == null) {
                            bitmapItem = new Bitmap(lastBitIndex);
                            verticalDB.put(token, bitmapItem);
                        }
                        // Register the bit in the bitmap for this item
                        bitmapItem.registerBit(sid, tid, sequencesSize);
                    }
                }
                transactionCount++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        //ADDED IN OUR VERSION OF THE CODE: calculate the class frequencies in the dataset
        determineClassFrequencies();
        //System.out.println("Class frequencies: " + classFreqs);
        
        lowestSupport = instClasses.size();
        
        
        classes = new String[classFreqs.size()];
        bestIG = new double[classFreqs.size()];
        //bestPattern = new String[classFreqs.size()];
        //bestPatternPrefixBitmap = new Bitmap[classFreqs.size()];
        
        for (int i=0; i<bestIG.length; i++){
        	//bestIG[i] = 0.0;
        	// Initialize the IGs for the one-vs-all problems with the information gain 
        	// If the best overall attribute found before launching VGEN
        	bestIG[i] = maxIGfoundOneVsAllProbs[i];
        }
        
        int classCounter = 0;
        for(String singleClass : classFreqs.keySet()){
        	classes[classCounter] = singleClass;
        	classCounter = classCounter + 1;
        }
        
        
        //ADDED IN OUR VERSION OF THE CODE: calculate initial entropy of the dataset
        initialEntropy = new double[classFreqs.size()];
        for (int i=0; i<classFreqs.size(); i++){     	
			HashMap<String,Double> oneVsAllClassFreqs = new HashMap<String,Double>();		
			double otherClassesFreq = 0.0;
			double referenceClassFreq = 0.0;
			String referenceClass = classes[i];
			for(Map.Entry<String, Double> entry : classFreqs.entrySet()){
				if(entry.getKey().equals(referenceClass)){
					referenceClassFreq = entry.getValue();
				}else{
					otherClassesFreq = otherClassesFreq + entry.getValue();
				}
			}
			if(referenceClassFreq > 0.0){
				oneVsAllClassFreqs.put(referenceClass, referenceClassFreq);
			}
			if(otherClassesFreq > 0.0){
				oneVsAllClassFreqs.put("otherClasses", otherClassesFreq);
			}
			
        	initialEntropy[i] = determineEntropy(oneVsAllClassFreqs);
        }
        		
        		
        //System.out.println("Initial entropy (1-vs-all problems): " + Arrays.toString(initialEntropy));
        

        initialEntropyMulticlass = determineEntropy(classFreqs);
        
        //System.out.println("Initial entropy (multiclass): " + initialEntropyMulticlass);
        
        
        // STEP2: REMOVE INFREQUENT ITEMS FROM THE DATABASE BECAUSE THEY WILL NOT APPEAR IN ANY FREQUENT SEQUENTIAL PATTERNS
        List<Integer> frequentItems = new ArrayList<Integer>();
        Iterator<Entry<Integer, Bitmap>> iter = verticalDB.entrySet().iterator();
        // we iterate over items from the vertical database that we have in memory
        while (iter.hasNext()) {
            //  we get the bitmap for this item
            Map.Entry<Integer, Bitmap> entry = (Map.Entry<Integer, Bitmap>) iter.next();
            // if the cardinality of this bitmap is lower than minsup
            if (entry.getValue().getSupport() < minsup) {
                // we remove this item from the database.
                iter.remove();
            } else {
                // otherwise, we save this item as a frequent
                // sequential pattern of size 1
            	// CHANGED
                // and we add this item to a list of frequent items
                // that we will use later.
               frequentItems.add(entry.getKey());
                // END CHANGED
            }
        }
        
        //System.out.println(verticalDB.size());
        // SET 2.1  SORT ITEMS BY DESCENDING SUPPORT
        Collections.sort(frequentItems, new Comparator<Integer>() {

			@Override
			public int compare(Integer arg0, Integer arg1) {
				return verticalDB.get(arg0).getSupport() - verticalDB.get(arg1).getSupport();
			}
        	
        });
        
        

        // STEP 3.1  CREATE CMAP
        coocMapEquals = new HashMap<Integer, Map<Integer, Integer>>(frequentItems.size());
        coocMapAfter = new HashMap<Integer, Map<Integer, Integer>>(frequentItems.size());

        for (int[] transaction : inMemoryDB) {
            short itemsetCount = 0;

            Set<Integer> alreadyProcessed = new HashSet<Integer>();
            Map<Integer, Set<Integer>> equalProcessed = new HashMap<>();
            loopI:
            for (int i = 0; i < transaction.length; i++) {
                Integer itemI = transaction[i];

                Set<Integer> equalSet = equalProcessed.get(itemI);
                if (equalSet == null) {
                    equalSet = new HashSet<Integer>();
                    equalProcessed.put(itemI, equalSet);
                }

                if (itemI < 0) {
                    itemsetCount++;
                    continue;
                }

                Bitmap bitmapOfItem = verticalDB.get(itemI);
                if (bitmapOfItem == null || bitmapOfItem.getSupport() < minsup) {
                    continue;
                }

                Set<Integer> alreadyProcessedB = new HashSet<Integer>(); // NEW

                boolean sameItemset = true;
                for (int j = i + 1; j < transaction.length; j++) {
                    Integer itemJ = transaction[j];

                    if (itemJ < 0) {
                        sameItemset = false;
                        continue;
                    }

                    Bitmap bitmapOfitemJ = verticalDB.get(itemJ);
                    if (bitmapOfitemJ == null || bitmapOfitemJ.getSupport() < minsup) {
                        continue;
                    }
//									if (itemI != itemJ){
                    Map<Integer, Integer> map = null;
                    if (sameItemset) {
                        if (!equalSet.contains(itemJ)) {
                            map = coocMapEquals.get(itemI);
                            if (map == null) {
                                map = new HashMap<Integer, Integer>();
                                coocMapEquals.put(itemI, map);
                            }
                            Integer support = map.get(itemJ);
                            if (support == null) {
                                map.put(itemJ, 1);
                            } else {
                                map.put(itemJ, ++support);
                            }
                            equalSet.add(itemJ);
                        }
                    } else if (!alreadyProcessedB.contains(itemJ)) {
                        if (alreadyProcessed.contains(itemI)) {
                            continue loopI;
                        }
                        map = coocMapAfter.get(itemI);
                        if (map == null) {
                            map = new HashMap<Integer, Integer>();
                            coocMapAfter.put(itemI, map);
                        }
                        Integer support = map.get(itemJ);
                        if (support == null) {
                            map.put(itemJ, 1);
                        } else {
                            map.put(itemJ, ++support);
                        }
                        alreadyProcessedB.add(itemJ); // NEW
                    }
                }
                alreadyProcessed.add(itemI);
            }
        }

        // STEP3: WE PERFORM THE RECURSIVE DEPTH FIRST SEARCH
        // to find longer sequential patterns recursively

        

        
        if(DEBUG_MODE) {
        	System.out.println("transaction count = " + transactionCount );
        } 
      
        
        //System.out.println("CMAP created");
        
        
        // NEW2014: SAVE ALL SINGLE FREQUENT ITEMS FIRST  BEFORE PERFORMING DEPTH FIRST SEARCH   =========
        List<PatternVGEN> prefixSingleItems = new ArrayList<PatternVGEN>(verticalDB.entrySet().size());
        for (Entry<Integer, Bitmap> entry : verticalDB.entrySet()) {
            // We create a prefix with that item
            PrefixVGEN prefix = new PrefixVGEN();
            prefix.addItemset(new Itemset(entry.getKey()));
            boolean itemIsEven = entry.getKey() % 2 == 0;
            if(itemIsEven) {
            	prefix.sumOfEvenItems = (Integer)entry.getKey();
            	prefix.sumOfOddItems = 0;
            }else {
            	prefix.sumOfEvenItems = 0;
            	prefix.sumOfOddItems = (Integer)entry.getKey();
            }
            PatternVGEN pattern = new PatternVGEN(prefix, entry.getValue());
            prefixSingleItems.add(pattern);
            
            // NEW 2014 : IMPORTANT!!!! -- > DON'T OUTPUT PATTERN IF SUPPORT IS EQUAL TO SDB SIZE
            // BUT NOTE THAT WE WILL STILL NEED TO DO THE DEPTH FIRST SEARCH FOR THIS PATTERN IN THE NEXT FOR LOOP...
            
            if(transactionCount != entry.getValue().getSupport()) {
               // SAVE THE PATTERN TO THE RESULT
               List<PatternVGEN> listPatterns = generatorPatterns.get(1).get(pattern.bitmap.sidsum);
               if(listPatterns == null) {
            	   listPatterns = new ArrayList<PatternVGEN>();
            	   generatorPatterns.get(1).put(pattern.bitmap.sidsum, listPatterns);
               }
        	   listPatterns.add(pattern);
               patternCount++;
            }
         }
        
        
        // Now I have all the single items
        
        if(prefixSingleItems.size() > 0){
        	longestPatternLength = 1;
        }
        
        // PART ADDED IN OUR VERSION OF THE CODE
        for (PatternVGEN pattern: prefixSingleItems) {
        	// The array contains the IG value for each 1-vs-all problem
        	// The problems are sorted as the class values contained in the array "classes"
        	double[] prefixIG = getPatternInfoGainOneVsAll(pattern.bitmap);
    		//System.out.println("prefixIGsing: " + prefixIG);
    		//System.out.println("prefixSUPPsing: " + pattern.bitmap.getSupport());
    		//System.out.println("prefixsing: " + pattern.prefix.toString());
        	// THIS ATTRIBUTE, INFOGAIN, HAS BEEN ADDED IN OUR VERSION OF THE CODE
        	pattern.infoGainsOneVsAll = prefixIG;
        	String[] itemsetArray = pattern.prefix.toString().split("-1");
        	int patternLength = 0;
        	for(String itemset : itemsetArray){
        		patternLength = patternLength + itemset.split(" ").length;
        	}
        	if(patternLength != 1){
        		System.out.println("Error in determining singleton pattern length: " + patternLength);
        		System.out.println("Pattern was: " + pattern.prefix.toString());
        		System.exit(-1);
        	}
        	for(int i=0; i<classes.length; i++){
        		//System.out.println("best prev ig: " + bestIG[i] + " ; " + prefixIG[i]);
        		//System.out.println("pattern: " + pattern.getPrefix().toString());
        		//System.out.println("support: " + pattern.getAbsoluteSupport());
            	if(prefixIG[i] > bestIG[i]){
            		//System.out.println("entrato per la classe: " + i);
            		bestIG[i] = prefixIG[i];
            		//bestPattern[i] = pattern.prefix.toString();
            		//bestPatternPrefixBitmap[i] = pattern.bitmap;
            		bestIGforLength.put(patternLength+";"+i, prefixIG[i]);
            		bestPatternforLength.put(patternLength+";"+i, pattern.prefix.toString());
            		bestPatternPrefixBitmapforLength.put(patternLength+";"+i, pattern.bitmap);
            	}      
        	}
        	
        	if(pattern.getAbsoluteSupport() < lowestSupport){
        		lowestSupport = pattern.getAbsoluteSupport();
        		lowestSupPattern = pattern.prefix.toString();
        	}


        	//System.out.println("SING_PREFIG: " + prefixIG + " " + pattern.getAbsoluteSupport());
        }
        // END OF THE PART ADDED IN OUR VERSION OF THE CODE
        
        
        // ADDED IN OUR VERSION OF THE CODE: SORTING THE SINGLE ITEM PATTERNS IN DESCENDING ORDER
        // ACCORDING TO THEIR IG VALUE SHOULD HELP A BIT IN THE SEARCH SPACE PRUNING...
        
        /*
        for (PatternVGEN pattern: prefixSingleItems) {
            System.out.println(pattern.prefix.toString());      	       	
        }*/
        
        //System.out.println("Sorting single items...");
        
        
        Collections.sort(prefixSingleItems, new Comparator<PatternVGEN>() {
                @Override
                public int compare(PatternVGEN pattern1, PatternVGEN pattern2)
                {
                	double maxIgPat1 = 0.0;
                	double maxIgPat2 = 0.0;
                	double avgIgPat1 = 0.0;
                	double avgIgPat2 = 0.0;
                	for(int i=0; i<classes.length; i++){
                		if(pattern1.infoGainsOneVsAll[i] > maxIgPat1){
                			maxIgPat1 = pattern1.infoGainsOneVsAll[i];
                		}
                		avgIgPat1 = avgIgPat1 + pattern1.infoGainsOneVsAll[i];
                		if(pattern2.infoGainsOneVsAll[i] > maxIgPat2){
                			maxIgPat2 = pattern2.infoGainsOneVsAll[i];
                		}
                		avgIgPat2 = avgIgPat2 + pattern2.infoGainsOneVsAll[i];
                	}
                	
                    //return  pattern1.infoGain.compareTo(pattern2.infoGain);
                	return avgIgPat1 > avgIgPat2 ? -1 : (avgIgPat1 < avgIgPat2 ? 1 : 0);
                }
            });	
           
            
        
        /*
        for (PatternVGEN pattern: prefixSingleItems) {
            System.out.println(pattern.prefix.toString() + " , " + pattern.infoGain);      	       	
        }*/

        //System.out.println("    > Done.");
        /*
        if(sequencesSize.size()==10){
        	System.out.println("arrivato");
        	try{
        	    PrintWriter writer = new PrintWriter("dataset_difficile.txt", "UTF-8");
        	    for(int i=0; i<inMemoryDB.size(); i++){
        	    	writer.println(Arrays.toString(inMemoryDB.get(i)));
        	    }
        	    writer.close();
        	    System.out.println("Scritto.");
        	} catch (IOException e) {
        	   System.out.println("Eccezione...");
        	}
        }*/
        
        
        //System.out.println("Single items have been generated, time: " + (System.currentTimeMillis()-startTime));
        
        
        // PERFORM THE DEPTH FIRST SEARCH
        //int counter = 1;
        for (PatternVGEN pattern: prefixSingleItems) {
            // We create a prefix with that item
            int item = pattern.prefix.get(0).get(0);
            if (maximumPatternLength > 1) {
            	//System.out.println("Pat: " + pattern.getPrefix().toString());
            	//System.out.println("Sup: " + pattern.getBitmap().getSupport());
            	//System.out.println("sto entrando...");
            	dfsPruning(pattern.prefix, pattern.bitmap, frequentItems, frequentItems, item, 2, item);
            	//System.out.println("Chiamato da for più esterno");
            	//System.out.println(counter);
            	//counter++;
            }
            
            //System.out.println("Single item expanded, in time: " + (System.currentTimeMillis()-startTime));
            
            if (maxElapsedTime > 0 && (System.currentTimeMillis()-startTime) > maxElapsedTime){
            	break;
            }
         }
        
        //System.out.println("Sto finendo...");
        
        // THE EMPTY SET IS ALWAYS GENERATOR, SO ADD IT TO THE RESULT SET
    	Bitmap bitmap = new Bitmap(0);
    	bitmap.setSupport(transactionCount);
    	PatternVGEN pat = new PatternVGEN(new PrefixVGEN(), bitmap);
    	List<PatternVGEN> listLevel0 = new ArrayList<PatternVGEN>();
    	listLevel0.add(pat);
    	generatorPatterns.get(0).put(0, listLevel0);
    	patternCount++;
        // END NEW 2014 =============
    	
    	//System.out.println("Ok, vgen() finito");
    }

    /**
     * This is the dfsPruning method as described in the SPAM paper.
     *
     * @param prefix the current prefix
     * @param prefixBitmap the bitmap corresponding to the current prefix
     * @param sn a list of items to be considered for i-steps
     * @param in a list of items to be considered for s-steps
     * @param hasToBeGreaterThanForIStep
     * @param m size of the current prefix in terms of items
     * @param lastAppendedItem the last appended item to the prefix
     * @throws IOException if there is an error writing a pattern to the output
     * file
     * @return TRUE IF A FREQUENT PATTERN WAS CREATED USING THE PREFIX.
     */
    void dfsPruning(PrefixVGEN prefix, Bitmap prefixBitmap, List<Integer> sn, List<Integer> in, int hasToBeGreaterThanForIStep, int m, Integer lastAppendedItem) throws IOException {
    	/**
    	 * - Calculate the prefix relative support
    	 * - Calculate the support immediately previous to the one of the prefix
    	 * - Calculate the upper bound on IG of the prefix
    	 * - Calculate the upper bound on IG of a prefix having the lower support
    	 * - Determine if prefixPrevUpperBoundIG >= prefixUpperBoundIG:
    	 * 		- if true, then continue the pattern exploration
    	 * 		- if false, then you are in the descending part of the IGUB graph:
    	 * 			- if IG_UB of the pattern is <= than the BEST_IG found so far, stop exploring the pattern
    	 * 			- else go on, determine the actual IG of the pattern, and update BEST_IG and BEST_PATTERN, if necessary
    	 */
    	//System.out.println("DFS pruning, elapsed time: " + (System.currentTimeMillis()-startTime));
    	
    	
    	// THE FOLLOWING PART HAS BEEN ADDED IN OUR VERSION OF THE CODE
    	double prefixRelativeSupport = ((double) prefixBitmap.getSupport())/((double) instClasses.size());
    	double prefixPrevRelativeSupport = ((((double) prefixBitmap.getSupport())-((double) 1.0)))/((double) instClasses.size());
    	
    	
    	if(prefixPrevRelativeSupport <= 0.0){
    		// Return, since that means that the pattern you are considering has a support of 1...  	
    		return;
    	}
    	
    	// The upper bound is calculated for each one-vs-all problem
    	double[] prefixUpperBoundIG = new double[classes.length];
    	double[] prefixPrevUpperBoundIG = new double[classes.length];
    	    	
    	for(int i=0; i<classes.length; i++){
        	double classFreq = classFreqs.get(classes[i]);
    		prefixUpperBoundIG[i] = initialEntropy[i] - condEntropyLBBinary(classFreq,prefixRelativeSupport);
    		prefixPrevUpperBoundIG[i] = initialEntropy[i] - condEntropyLBBinary(classFreq,prefixPrevRelativeSupport);
    	}
    	
    	//System.out.println("Pattern:" + prefix.toString());
    	//System.out.println("IG: " + prefixUpperBoundIG + " IGPR " + prefixPrevUpperBoundIG + " SUP " + prefixRelativeSupport + " SUPPR " + prefixPrevRelativeSupport);
    	
    	// The "search space pruning" part has been generalized to an "OR", on each of the one-vs-all problems
    	
    	boolean allStop = true;
    	for(int i=0; i<classes.length; i++){
        	if(prefixPrevUpperBoundIG[i] <= prefixUpperBoundIG[i]){
        		// You are in the "non-ascending" part of the graph, reading it from right to left
        		if(prefixUpperBoundIG[i] > bestIG[i]){
        			// The upper bound on IG is higher than current best IG value for that class
            		allStop = false;
            		break;
        		}
        	}else{
        		// You are in the "ascending" part of the graph for that class, reading it from right to left
        		allStop = false;
        		break;
        	}
    	}
    	
    	// If the pattern is useless for all the one-vs-all problems, then stop exploring it
    	if(allStop){
    		return;
    	}
    	
    	
    	double[] prefixIG = getPatternInfoGainOneVsAll(prefixBitmap);
		//System.out.println("PSEQ: " + prefix.toString() + "PREFIG: " + prefixIG + " " + prefixBitmap.getSupport());

    	
    	/*if(prefix.toString().equals("0 -1 3 -1 ")){
    		System.out.println(" >>>>>>> trovato");
    		System.out.println(Arrays.toString(prefixIG));
    	}*/
    	
    	String[] itemsetArray = prefix.toString().split("-1");
    	int patternLength = 0;
    	for(String itemset : itemsetArray){
    		patternLength = patternLength + itemset.split(" ").length;
    	}
    	
    	for(int i=0; i<classes.length; i++){
        	if(prefixIG[i] > bestIG[i]){
        		bestIG[i] = prefixIG[i];
        		//bestPattern[i] = prefix.toString();
        		//bestPatternPrefixBitmap[i] = prefixBitmap;
        	}  
        	if(bestIGforLength.get(patternLength+";"+i) == null || prefixIG[i] > bestIGforLength.get(patternLength+";"+i)){
          		bestIGforLength.put(patternLength+";"+i, prefixIG[i]);
        		bestPatternforLength.put(patternLength+";"+i, prefix.toString());
        		bestPatternPrefixBitmapforLength.put(patternLength+";"+i, prefixBitmap);
        	}   
        	if(patternLength > longestPatternLength){
        		longestPatternLength = patternLength;
        	}
    	}    
    	

    	  	
    	if(prefixBitmap.getSupport() < lowestSupport){
    		lowestSupport = prefixBitmap.getSupport();
    		lowestSupPattern = prefix.toString();
    	}
    	
    	//END OF THE PART ADDED IN OUR VERSION OF THE CODE
    	
    	//System.out.println("BEFORE S STEPS: " + (System.currentTimeMillis()-startTime));
    	
    	//		System.out.println(prefix.toString());

        //  ======  S-STEPS ======
        // Temporary variables (as described in the paper)
        List<Integer> sTemp = new ArrayList<Integer>();
        List<Bitmap> sTempBitmaps = new ArrayList<Bitmap>();

        // for CMAP pruning, we will only check against the last appended item
        Map<Integer, Integer> mapSupportItemsAfter = coocMapAfter.get(lastAppendedItem);

        // for each item in sn
        loopi:
        for (Integer i : sn) {

            // LAST POSITION PRUNING
            /*if (useLastPositionPruning && lastItemPositionMap.get(i) < prefixBitmap.firstItemsetID) {
             //				System.out.println("TEST");
             continue loopi;
             }*/

            // CMAP PRUNING
            // we only check with the last appended item
            if (useCMAPPruning) {
                if (mapSupportItemsAfter == null) {
                    continue loopi;
                }
                Integer support = mapSupportItemsAfter.get(i);
                if (support == null || support < minsup) {
//							System.out.println("PRUNE");
                    continue loopi;
                }
            }

            // perform the S-STEP with that item to get a new bitmap
            Bitmap.INTERSECTION_COUNT++;
            Bitmap newBitmap = prefixBitmap.createNewBitmapSStep(verticalDB.get(i), sequencesSize, lastBitIndex, maxGap);
            // if the support is higher than minsup
            if (newBitmap.getSupportWithoutGapTotal() >= minsup) {
                // record that item and pattern in temporary variables
                sTemp.add(i);
                sTempBitmaps.add(newBitmap);
            }
        }
        // for each pattern recorded for the s-step
        for (int k = 0; k < sTemp.size(); k++) {
        	// STRATEGY: NEWWW
            
            int item = sTemp.get(k);
            // create the new prefix
            PrefixVGEN prefixSStep = prefix.cloneSequence();
            prefixSStep.addItemset(new Itemset(item));
            if(item % 2 == 0) {
            	prefixSStep.sumOfEvenItems = item + prefix.sumOfEvenItems;
            	prefixSStep.sumOfOddItems = prefix.sumOfOddItems;
            }else {
            	prefixSStep.sumOfEvenItems = prefix.sumOfEvenItems;
            	prefixSStep.sumOfOddItems = item + prefix.sumOfOddItems;
            }
//            prefixSStep.sumOfItems = item + prefix.sumOfItems;
            
            // create the new bitmap
            Bitmap newBitmap = sTempBitmaps.get(k);

            // save the pattern to the file

           if(newBitmap.getSupport() >= minsup) {
        	   
        	   // NEW STRATEGY :  IMMEDIATE BACKWARD EXTENSION
           boolean hasNoImmediateBackwardExtension = useImmediateBackwardChecking ||
        		   prefixBitmap.getSupport() != newBitmap.getSupport();
        	   
	            if (maximumPatternLength > m && hasNoImmediateBackwardExtension ) {
	            	
	                boolean hasBackWardExtension = savePatternMultipleItems(prefixSStep, newBitmap, m);
	                // NEW 2014: IF BACKWARD EXTENSION, THEN WE DON'T CONTINUE...
	                if(hasBackWardExtension == false) {
	                    if (maxElapsedTime <= 0 || (System.currentTimeMillis()-startTime) < maxElapsedTime){
	                    	dfsPruning(prefixSStep, newBitmap, sTemp, sTemp, item, m + 1, item);
	                    	//System.out.println("Chiamato da parte su S steps");
	                    }
	                	//dfsPruning(prefixSStep, newBitmap, sTemp, sTemp, item, m + 1, item);
	                }
	            }
           }
        }
        
        //System.out.println("BEFORE I STEPS: " + (System.currentTimeMillis()-startTime));

        Map<Integer, Integer> mapSupportItemsEquals = coocMapEquals.get(lastAppendedItem);
        // ========  I STEPS =======
        // Temporary variables
        List<Integer> iTemp = new ArrayList<Integer>();
        List<Bitmap> iTempBitmaps = new ArrayList<Bitmap>();

        // for each item in in
        loop2:
        for (Integer i : in) {


            // the item has to be greater than the largest item
            // already in the last itemset of prefix.
            if (i > hasToBeGreaterThanForIStep) {

                // LAST POSITION PRUNING
                /*if (useLastPositionPruning && lastItemPositionMap.get(i) < prefixBitmap.firstItemsetID) {
                 continue loop2;
                 }*/

                // CMAP PRUNING
                if (useCMAPPruning) {
                    if (mapSupportItemsEquals == null) {
                        continue loop2;
                    }
                    Integer support = mapSupportItemsEquals.get(i);
                    if (support == null || support < minsup) {
                        continue loop2;
                    }
                }

                // Perform an i-step with this item and the current prefix.
                // This creates a new bitmap
                Bitmap.INTERSECTION_COUNT++;
                Bitmap newBitmap = prefixBitmap.createNewBitmapIStep(verticalDB.get(i), sequencesSize, lastBitIndex);
                // If the support is no less than minsup
                if (newBitmap.getSupport() >= minsup) {
                    // record that item and pattern in temporary variables
                    iTemp.add(i);
                    iTempBitmaps.add(newBitmap);
                }
            }
        }
        
        //System.out.println("AFTER I STEPS: " + (System.currentTimeMillis()-startTime)); 
        
        // for each pattern recorded for the i-step
        for (int k = 0; k < iTemp.size(); k++) {// STRATEGY: NEWWW
           // atLeastOneFrequentExtension = true;
        	//System.out.println("k on tot: " + k + " / " + (iTemp.size()-1));
            
            int item = iTemp.get(k);
            // create the new prefix
            PrefixVGEN prefixIStep = prefix.cloneSequence();
            prefixIStep.getItemsets().get(prefixIStep.size() - 1).addItem(item);
            if(item % 2 == 0) {
            	prefixIStep.sumOfEvenItems = item + prefix.sumOfEvenItems;
            	prefixIStep.sumOfOddItems = prefix.sumOfOddItems;
            }else {
            	prefixIStep.sumOfEvenItems = prefix.sumOfEvenItems;
            	prefixIStep.sumOfOddItems = item + prefix.sumOfOddItems;
            }
            // create the new bitmap
            Bitmap newBitmap = iTempBitmaps.get(k);
            
            //System.out.println("BACKWEXT?: " + (prefixBitmap.getSupport() == newBitmap.getSupport()));
            
         // NEW STRATEGY :  IMMEDIATE BACKWARD EXTENSION
            boolean hasNoImmediateBackwardExtension = useImmediateBackwardChecking ||
         		   prefixBitmap.getSupport() == newBitmap.getSupport();
            
            //System.out.println("qua ci sono");
            
            //System.out.println("maximumPatternLength: " + maximumPatternLength + ", m: "+ m);
            //System.out.println("hasNoImmediateBackwardExtension: " + hasNoImmediateBackwardExtension);
            
            if (maximumPatternLength > m  && hasNoImmediateBackwardExtension) {
            	//System.out.println("sono anche qua");
            	boolean hasBackWardExtension = savePatternMultipleItems(prefixIStep, newBitmap, m);
            	//System.out.println("hasBackWardExtension: " + hasBackWardExtension);
                // NEW 2014: IF NO BACKWARD EXTENSION, THEN WE TRY TO EXTEND THAT PATTERN
                if(hasBackWardExtension == false) {
                	//System.out.println("sono persino qui!");
                	if (maxElapsedTime <= 0 || (System.currentTimeMillis()-startTime) < maxElapsedTime){
                		//System.out.println("e qua?");
                		dfsPruning(prefixIStep, newBitmap, sTemp, iTemp, item, m + 1, item);
                		//System.out.println("Chiamato da parte su isteps");
                    }
                	//dfsPruning(prefixIStep, newBitmap, sTemp, iTemp, item, m + 1, item);
                }
            }
        }
        // check the memory usage
        MemoryLogger.getInstance().checkMemory();
       
        //System.out.println("ENDED...");
        
    }  

    /**
     * Save a pattern of size > 1 to the output file.
     *
     * @param prefix the prefix
     * @param bitmap its bitmap
     * @throws IOException exception if error while writing to the file
     * @return true IF THE PATTERN HAS A BACKWARD EXTENSION WITH THE SAME PROJECTED DATABASE
     */
    private boolean savePatternMultipleItems(PrefixVGEN prefix, Bitmap bitmap, int length) throws IOException {
//    	System.out.println("prefix :" + prefix);
    	int sidsum = bitmap.sidsum;
    	
    	// IF THE SUPPORT OF THIS PATTERN "PREFIX" IS THE SUPPORT OF THE EMPTY SET, THEN
    	// THIS PATTERN IS NOT A GENERATOR.
    	if(bitmap.getSupport() == transactionCount) {
    		return false;
    	}
    	

        // WE COMPARE PATTERN "PREFIX" WITH SMALLER PATTERNS FOR SUB-PATTERN CHECKING
    	boolean mayBeAGenerator = true;
    	// FOR PATTERNS OF SIZE 1 TO THE SIZE OF THE PATTERN MINUS 1
       	for(int i=1; i < length && i < generatorPatterns.size(); i++) {
       		// GET ALL THE PATTERNS HAVING THE SAME SID-SUM AS THE CURRENT PATTERN
       		List<PatternVGEN> level = generatorPatterns.get(i).get(sidsum); 
       		if(level == null) {
       			continue;
       		}
       		for(PatternVGEN pPrime : level) {
   	        	
   	        	// CHECK THE SUM OF EVEN AND ODD ITEMS AND THE SUPPORT
   	        	if(prefix.sumOfEvenItems >= pPrime.prefix.sumOfEvenItems &&
   	     			   prefix.sumOfOddItems >= pPrime.prefix.sumOfOddItems &&
   	     			   bitmap.getSupport() == pPrime.getAbsoluteSupport() &&
   	     			   strictlyContains(prefix, pPrime.prefix)) {
   	        		
   	        		// CHECK HERE IF THERE IS A BACKWARD EXTENSION...
   	        		if (useBackwardPruning) {
   	        			if(isThereBackwardExtension(bitmap, pPrime.bitmap)){
   	        				// THERE IS A BACKWARD EXTENSION SO WE RETURN TRUE TO PRUNE EXTENSIONS
   	        				// OF THE PATTERN "PREFIX"
   	        				return true;  
   	        			}else {
   	        				// WE FLAG THE PATTERN "PREFIX" HAS NOT BEING A GENERATOR BUT
   	        				// WE CONTINUE COMPARING WITH OTHER PATTERNS TO SEE IF WE COULD PRUNE
   	        				mayBeAGenerator = false;
   	        			}
   	        		}else {
   	        			// IF BACKWARD EXTENSION CHECKING IS DISABLED, WE RETURN FALSE  
   	        		// WE JUST RETURN FALSE IF WE DON'T USE THE BACKWARD PRUNING. THIS IS A TRADE-OFF
   	   	        		return false;  
   	        		}
   	        		// END IMPORTANT
   	        	}
   			}
           }
    	
       	if(mayBeAGenerator == false) {
       		return false;
       	}
    	
        // WE COMPARE WITH LARGER PATTERNS FOR SUPER-PATTERN CHECKING
    	for(int i=generatorPatterns.size()-1; i > length; i--) {
    		
       		List<PatternVGEN> level = generatorPatterns.get(i).get(sidsum); 
       		if(level == null) {
       			continue;
       		}
       		Iterator<PatternVGEN> iter  = level.iterator(); 
       		
       		while (iter.hasNext()) {
   	        	PatternVGEN pPrime = iter.next();

    			if(prefix.sumOfEvenItems <= pPrime.prefix.sumOfEvenItems &&
    			   prefix.sumOfOddItems <= pPrime.prefix.sumOfOddItems &&
    			   bitmap.getSupport() == pPrime.getAbsoluteSupport() && 
    			   strictlyContains(pPrime.prefix, prefix)) {
    				
	    	 		patternCount--;  // DECREASE COUNT
	        		iter.remove();
	        	}
    		}
    	}

        // OTHERWISE THE PATTERN "PREFIX" MAY BE A GENERATOR SO WE KEEP IT 
        while(generatorPatterns.size() -1 < length) {
        	generatorPatterns.add(new HashMap<Integer, List<PatternVGEN>>());
        }
        
        List<PatternVGEN> listPatterns = generatorPatterns.get(length).get(sidsum);
        if(listPatterns == null) {
     	   listPatterns = new ArrayList<PatternVGEN>();
     	   generatorPatterns.get(length).put(sidsum, listPatterns);
        }

        patternCount++;  // INCREASE COUNT
        listPatterns.add(new PatternVGEN(prefix, bitmap));

        return false; // No backward extension has been found. 
    }
    
    /**
     * Check if there is a backward extension by comparing the bitmap of two patterns
     * P1 and P2, such that P1 is a superset of P2
     * @param bitmap  bitmap of P1
     * @param bitmap2 bitmap of P2
     * @return true if there is a backward extension
     */
    private boolean isThereBackwardExtension(Bitmap bitmap1, Bitmap bitmap2) {
//    	System.out.println("is there backward?");
//    	System.out.println(bitmap1.bitmap.toString());
//    	System.out.println(bitmap2.bitmap.toString());
    	BitSet bitset1 = bitmap1.bitmap;
    	BitSet bitset2 = bitmap2.bitmap;
    	
    	int currentBit1 = bitset1.nextSetBit(0);
    	int currentBit2 = bitset2.nextSetBit(0);
    	
    	do {
    		if(currentBit1 > currentBit2) {
    			return false;
    		}
    		
    		currentBit1 = bitset1.nextSetBit(currentBit1+1);
        	currentBit2 = bitset2.nextSetBit(currentBit2+1);
    	}while(currentBit1 >0);
    	
    	return true;
//		return bitmap.equals(bitmap2);
	}

	/**
	 * This methods checks if a seq. pattern "pattern2" is strictly contained in a seq. pattern "pattern1".
     * @param pattern1 a sequential pattern
     * @param pattern2 another sequential pattern
	 * @return true if the pattern1 contains pattern2.
	 */
	boolean strictlyContains(PrefixVGEN pattern1, PrefixVGEN pattern2) {
//		// if pattern2 is larger or equal in size, then it cannot be contained in pattern1
//		if(pattern1.size() <= pattern2.size()){
//			return false;
//		} 
		
		// To see if pattern2 is strictly contained in pattern1,
		// we will search for each itemset i of pattern2 in pattern1 by advancing
		// in pattern 1 one itemset at a time.
		
		int i =0; // position in pattern2
		int j= 0; // position in pattern1
		while(true){
			//if the itemset at current position in pattern1 contains the itemset
			// at current position in pattern2
			if(pattern1.get(j).containsAll(pattern2.get(i))){
				// go to next itemset in pattern2
				i++;
				
				// if we reached the end of pattern2, then return true
				if(i == pattern2.size()){
					return true;
				}
			}
				
			// go to next itemset in pattern1
			j++;
			
			// if we reached the end of pattern1, then pattern2 is not strictly included
			// in it, and return false
			if(j >= pattern1.size()){
				return false;
			}
			
//			// lastly, for optimization, we check how many itemsets are left to be matched.
//			// if there is less itemsets left in pattern1 than in pattern2, then it will
//			// be impossible to get a total match, and so we return false.
			if((pattern1.size() - j) < pattern2.size()  - i){
				return false;
			}
		}
	}

    /**
     * Print the statistics of the algorithm execution to System.out.
     */
    public void printStatistics() {
        StringBuilder r = new StringBuilder(200);
        r.append("=============  VGEN v0.97- STATISTICS =============\n Total time ~ ");
        r.append(endTime - startTime);
        r.append(" ms\n");
        r.append(" Frequent sequences count : " + patternCount);
        r.append('\n');
        r.append(" Max memory (mb) : ");
        r.append(MemoryLogger.getInstance().getMaxMemory());
        r.append(patternCount);
        r.append('\n');
        r.append("minsup " + minsup);
        r.append('\n');
        r.append("Intersection count " + Bitmap.INTERSECTION_COUNT + " \n");
        r.append("===================================================\n");
        //double bestOverallIG = 0.0;
        // Key of the two following hashmaps is the pattern length
        HashMap<Integer,Double> bestOverallIGforLength = new HashMap<Integer,Double>();
        HashMap<Integer,Integer> bestPatternIndexforLength = new HashMap<Integer,Integer>();
        //int bestPatternIndex = -1;       
        for (String key : bestIGforLength.keySet()) {
        	// They key is made as: pattern_length;pattern_index
        	String[] splittedKey = key.split(";");
        	int classIndex = Integer.parseInt(splittedKey[1]);
        	int patternLength = Integer.parseInt(splittedKey[0]);
        	double patternOverallIG = getPatternInfoGain(bestPatternPrefixBitmapforLength.get(key));
            r.append("Max IG found (1-vs-all class: " + classes[classIndex] +  ", pattern length: " + patternLength  +"): " + bestIGforLength.get(key) + " , by the pattern: " + bestPatternforLength.get(key) + "\n");
        	r.append("    > Overall IG of the pattern: " + patternOverallIG + "\n");   
        	if(bestOverallIGforLength.get(patternLength) == null || patternOverallIG > bestOverallIGforLength.get(patternLength)){
        		bestOverallIGforLength.put(patternLength, patternOverallIG);
        		bestPatternIndexforLength.put(patternLength, classIndex);
        	}
        }
        
        /*
        for(int i=0; i<classes.length; i++){
        	double patternOverallIG = getPatternInfoGain(bestPatternPrefixBitmap[i]);
            r.append("Max IG found (1-vs-all class: " + classes[i] +  "): " + bestIG[i] + " , by the pattern: " + bestPattern[i] + "\n");
        	r.append("    > Overall IG of the pattern: " + patternOverallIG + "\n");   
        	if(patternOverallIG > bestOverallIG){
        		bestOverallIG = patternOverallIG;
        		bestPatternIndex = i;
        	}

        }
        */
        for (int key : bestOverallIGforLength.keySet()) {
        	r.append("Best overall pattern for length "+ key +": "  + bestPatternforLength.get(key+";"+bestPatternIndexforLength.get(key)) +"\n");
        }
        
        //r.append("Best overall pattern: "  + bestPattern[bestPatternIndex] +"\n");
        r.append("Min support: " + ((double)lowestSupport/((double) instClasses.size())) + " , by the pattern: " + lowestSupPattern + "\n");
        //r.append("TOT ig_ub_time: " + totalTimeIGUB);
        //r.append("TOT ig_calc_time: " + totalTimeIGCALC);
        //r.append("TOT subtime ic calc: " +  totalSubTimeIGCALC);
        System.out.println(r.toString());
    }

    /**
     * Get the maximum length of patterns to be found (in terms of itemset
     * count)
     *
     * @return the maximumPatternLength
     */
    public int getMaximumPatternLength() {
        return maximumPatternLength;
    }
    
    /**
     * Get the maximum gap between itemsets
     *
     * @return the maxGap
     */
    public int getMaxGap() {
        return maxGap;
    }

    /**
     * Set the maximum length of patterns to be found (in terms of itemset
     * count)
     *
     * @param maximumPatternLength the maximumPatternLength to set
     */
    public void setMaximumPatternLength(int maximumPatternLength) {
        this.maximumPatternLength = maximumPatternLength;
    }
    
	/**
	 * Write the result to an output file
	 * @param path the output file path
	 * @throws IOException exception if an error occur when writing the file.
	 */
	public void writeResultTofile(String path) throws IOException {
		// for each level (pattern having a same size)
		for(Map<Integer, List<PatternVGEN>> level : generatorPatterns) {
			// for each list of patterns having the same hash value
			for(List<PatternVGEN> patterns : level.values()) {
				// for each pattern
				for(PatternVGEN pattern : patterns) {
					// save the pattern
					StringBuilder r = new StringBuilder("");
					for(Itemset itemset : pattern.prefix.getItemsets()){
//						r.append('(');
						for(Integer item : itemset.getItems()){
							String string = item.toString();
							r.append(string);
							r.append(' ');
						}
						r.append("-1 ");
					}

					r.append("#SUP: ");
					r.append(pattern.getAbsoluteSupport());
			        if(outputSequenceIdentifiers) {
			        	r.append(" #SID: ");
			        	r.append(pattern.bitmap.getSIDs(sequencesSize));
			        }
					
					//writer.write(r.toString());
					//writer.newLine();
				}
			}
		}
	}
	
	/**
	 * This method allows to specify the maximum gap 
	 * between itemsets of patterns found by the algorithm. 
	 * If set to 1, only patterns of contiguous itemsets
	*  will be found (no gap).
	 * @param maxGap the maximum gap (an integer)
	 */
	public void setMaxGap(int maxGap) {
		this.maxGap = maxGap;
	}

	/**
	 * This method allows to specify if sequence identifiers should be shown in the output
	 * @param showSequenceIdentifiers if true, sequence identifiers will be shown (boolean)
	 */
	public void showSequenceIdentifiersInOutput(boolean showSequenceIdentifiers) {
		this.outputSequenceIdentifiers = showSequenceIdentifiers;
	}
	
	
	
	/**
	 * This method allows to calculate the class frequencies in the dataset
	 * It has been added in our version of the code
	 */	
	public void determineClassFrequencies() {
		double numInstances = (double) instClasses.size();
		for(int i = 0; i < instClasses.size(); i++){
			String instClass = instClasses.get(i);
			if(classFreqs.containsKey(instClass)){
				double prevVal = classFreqs.get(instClass);
				prevVal = prevVal + 1.0/numInstances;
				classFreqs.put(instClass, prevVal);
			}else{
				classFreqs.put(instClass, 1.0/numInstances);
			}
		}
	}
	
	
	/**
	 * This method allows to calculate the entropy of a dataset
	 * It has been added in our version of the code
	 */
	public double determineEntropy(HashMap<String,Double> classFreqsIn){
		double entropy = 0.0;
		for(String singleClass : classFreqsIn.keySet()){
			double freq = classFreqsIn.get(singleClass);
			freq = freq * (Math.log(freq)/Math.log(2));
			entropy = entropy + freq;
		}
		return entropy*-1;
	}
	
	
	/**
	 * This method calculates the lower bound on conditional entropy given a pattern, as in
	 * the article "Discriminative Frequent Pattern Analysis for Effective Classification" (2007)
	 * Then, the upper bound on information gain can be derived, as
	 * INFORMATION_GAIN = INITIAL_ENTROPY - CONDITIONAL_ENTROPY
	 * p: relative frequency of one of the two classes of the dataset
	 * t: relative frequency of the sequences in which the pattern appears
	 */
	public double condEntropyLBBinary(double p, double t){
		//long startTime = System.currentTimeMillis();

	    double condEntropyLB = 0.0;
		if(t <= p){
			double condEntropyLB1 = (t-1)*(((p-t)/(1-t))*(Math.log((p-t)/(1-t))/Math.log(2))+((1-p)/(1-t))*(Math.log((1-p)/(1-t))/Math.log(2)));
			double condEntropyLB2 = -p*(Math.log(p/(1-t))/Math.log(2))+(t-1+p)*(Math.log((1-p-t)/(1-t))/Math.log(2));
			//System.out.println(condEntropyLB1 + " ; "+ condEntropyLB2 + " S "+ t + " C " + p);
			if(condEntropyLB1 <= condEntropyLB2){
				condEntropyLB = condEntropyLB1;
			}else{
				condEntropyLB = condEntropyLB2;
			}
		}else{
			double condEntropyLB1 = -p*(Math.log(p/t)/Math.log(2))-(t-p)*(Math.log(1-(p/t))/Math.log(2));
			double condEntropyLB2 = -(t-1+p)*(Math.log((t-1+p)/t)/Math.log(2))-(1-p)*(Math.log((1-p)/t)/Math.log(2));
			if(condEntropyLB1 <= condEntropyLB2){
				condEntropyLB = condEntropyLB1;
			}else{
				condEntropyLB = condEntropyLB2;
			}
		}
		
		if(Double.isNaN(condEntropyLB)){
			condEntropyLB = 0.0;
		}
		
		//long endTime = System.currentTimeMillis();
		//totalTimeIGUB = totalTimeIGUB + (endTime - startTime);
		
		return condEntropyLB;
		 
	}
	
	
	/**
	 * This method calculates the information gain of a pattern
	 * This part has been added in our version of the code
	 */
	
	public double getPatternInfoGain(Bitmap prefixBitmap){
		//long startTime = System.currentTimeMillis();
		
		double numInstances = (double) instClasses.size();
		double nSeqsWithPattern = (double) prefixBitmap.getSupport();
		double freqSeqsWithPattern = nSeqsWithPattern/numInstances;
		
		//long initSubTime = System.currentTimeMillis();
		//HashMap<Integer,Boolean> seqsWithPatternBoolHMAP = new HashMap<Integer,Boolean>();
		// In Java, the boolean array gets initialized to false value
		boolean[] seqsWithPatternBool = new boolean[(int) numInstances];
		// SIDs start from 0
		String[] seqsWithPattern = prefixBitmap.getSIDs(sequencesSize).split(" ");
		//List<String> listSeqsWithPattern = Arrays.asList(seqsWithPattern);
		for(String sid : seqsWithPattern){
			seqsWithPatternBool[Integer.parseInt(sid)] = true;
			//seqsWithPatternBoolHMAP.put(Integer.parseInt(sid), false);
		}
		//long endSubTime = System.currentTimeMillis();
		//totalSubTimeIGCALC = totalSubTimeIGCALC + (endSubTime - initSubTime);
		
		//System.out.println(listSeqsWithPattern.toString());
		
		HashMap<String,Double> classFreqsWithPattern = new HashMap<String,Double>();
		HashMap<String,Double> classFreqsWithoutPattern = new HashMap<String,Double>();
		
		//Determine the class frequencies for the instances containing the pattern and those that do not
		for(int i = 0; i < numInstances; i++){
			if(seqsWithPatternBool[i]){
				// Then, that is one of the sequences containing the pattern
				String instClass = instClasses.get(i);
				if(classFreqsWithPattern.containsKey(instClass)){
					double prevVal = classFreqsWithPattern.get(instClass);
					prevVal = prevVal + 1.0/nSeqsWithPattern;
					classFreqsWithPattern.put(instClass, prevVal);
				}else{
					classFreqsWithPattern.put(instClass, 1.0/nSeqsWithPattern);
				}
				
			}else{
				// Else, that is one of the sequences not containing the pattern
				String instClass = instClasses.get(i);
				if(classFreqsWithoutPattern.containsKey(instClass)){
					double prevVal = classFreqsWithoutPattern.get(instClass);
					prevVal = prevVal + 1.0/(numInstances-nSeqsWithPattern);
					classFreqsWithoutPattern.put(instClass, prevVal);
				}else{
					classFreqsWithoutPattern.put(instClass, 1.0/(numInstances-nSeqsWithPattern));
				}		
			}
		}
		
		//long initSubTime = System.currentTimeMillis();
		double entropySeqsWithPattern = determineEntropy(classFreqsWithPattern);
		double entropySeqsWithoutPattern = determineEntropy(classFreqsWithoutPattern);
		//long endSubTime = System.currentTimeMillis();
		//totalSubTimeIGCALC = totalSubTimeIGCALC + (endSubTime - initSubTime);
		
		double splitEntropy = freqSeqsWithPattern*entropySeqsWithPattern + (1.0-freqSeqsWithPattern)*entropySeqsWithoutPattern;
		
		if(Double.isNaN(splitEntropy)){
			System.out.println("NaN found!!!");
			System.out.println(classFreqsWithPattern);
			System.out.println(classFreqsWithoutPattern);
			System.exit(1);
		}
		
		//long endTime = System.currentTimeMillis();
		//totalTimeIGCALC = totalTimeIGCALC + (endTime - startTime);
		
		return (initialEntropyMulticlass - splitEntropy);
	}	
	
	
	
	/**
	 * This method calculates the information gain of a pattern
	 * It does it for every 1-vs-all problem which can be derived from the main problem
	 * This part has been added in our version of the code
	 */
	
	public double[] getPatternInfoGainOneVsAll(Bitmap prefixBitmap){
		//long startTime = System.currentTimeMillis();
		
		double numInstances = (double) instClasses.size();
		double nSeqsWithPattern = (double) prefixBitmap.getSupport();
		double freqSeqsWithPattern = nSeqsWithPattern/numInstances;
		
		//long initSubTime = System.currentTimeMillis();
		//HashMap<Integer,Boolean> seqsWithPatternBoolHMAP = new HashMap<Integer,Boolean>();
		// In Java, the boolean array gets initialized to false value
		boolean[] seqsWithPatternBool = new boolean[(int) numInstances];
		// SIDs start from 0
		String[] seqsWithPattern = prefixBitmap.getSIDs(sequencesSize).split(" ");
		//List<String> listSeqsWithPattern = Arrays.asList(seqsWithPattern);
		for(String sid : seqsWithPattern){
			seqsWithPatternBool[Integer.parseInt(sid)] = true;
			//seqsWithPatternBoolHMAP.put(Integer.parseInt(sid), false);
		}
		//long endSubTime = System.currentTimeMillis();
		//totalSubTimeIGCALC = totalSubTimeIGCALC + (endSubTime - initSubTime);
		
		//System.out.println(listSeqsWithPattern.toString());
		
		// These hashmaps keep the class frequency distribution for the two potential
		// children: the one with instances having the pattern, and the one with instances which do not
		HashMap<String,Double> classFreqsWithPattern = new HashMap<String,Double>();
		HashMap<String,Double> classFreqsWithoutPattern = new HashMap<String,Double>();
		
		//Determine the class frequencies for the instances containing the pattern and those that do not
		for(int i = 0; i < numInstances; i++){
			if(seqsWithPatternBool[i]){
				// Then, that is one of the sequences containing the pattern
				// instClass is a string array containing the class for each of the instances
				String instClass = instClasses.get(i);
				if(classFreqsWithPattern.containsKey(instClass)){
					double prevVal = classFreqsWithPattern.get(instClass);
					prevVal = prevVal + 1.0/nSeqsWithPattern;
					classFreqsWithPattern.put(instClass, prevVal);
				}else{
					classFreqsWithPattern.put(instClass, 1.0/nSeqsWithPattern);
				}
				
			}else{
				// Else, that is one of the sequences not containing the pattern
				String instClass = instClasses.get(i);
				if(classFreqsWithoutPattern.containsKey(instClass)){
					double prevVal = classFreqsWithoutPattern.get(instClass);
					prevVal = prevVal + 1.0/(numInstances-nSeqsWithPattern);
					classFreqsWithoutPattern.put(instClass, prevVal);
				}else{
					classFreqsWithoutPattern.put(instClass, 1.0/(numInstances-nSeqsWithPattern));
				}		
			}
		}
		
		//Now I have the class distribution for each of the two potential children
		
		// The following array contains the information gain value for each 1-vs-all problem
		double[] oneVsAllGains = new double[classFreqs.size()];
				
		//long initSubTime = System.currentTimeMillis();
		
		
		// Calculating the entropy for each of the one-vs-all problems
		for(int i = 0; i < classes.length; i++){
			String referenceClass = classes[i];		
			
			HashMap<String,Double> oneVsAllClassFreqsWithPattern = new HashMap<String,Double>();
			HashMap<String,Double> oneVsAllClassFreqsWithoutPattern = new HashMap<String,Double>();	
			
			double otherClassesFreq = 0.0;
			double referenceClassFreq = 0.0;
			for(Map.Entry<String, Double> entry : classFreqsWithPattern.entrySet()){
				if(entry.getKey().equals(referenceClass)){
					referenceClassFreq = entry.getValue();
				}else{
					otherClassesFreq = otherClassesFreq + entry.getValue();
				}
			}
			if(referenceClassFreq > 0.0){
				oneVsAllClassFreqsWithPattern.put(referenceClass, referenceClassFreq);
			}
			if(otherClassesFreq > 0.0){
				oneVsAllClassFreqsWithPattern.put("otherClasses", otherClassesFreq);
			}
			
			
			
			otherClassesFreq = 0.0;
			referenceClassFreq = 0.0;
			for(Map.Entry<String, Double> entry : classFreqsWithoutPattern.entrySet()){
				//System.out.println(entry.getKey() + " || "+referenceClass);
				if(entry.getKey().equals(referenceClass)){
					//System.out.println("entro");
					referenceClassFreq = entry.getValue();
				}else{
					otherClassesFreq = otherClassesFreq + entry.getValue();
				}
			}
			if(referenceClassFreq > 0.0){
				oneVsAllClassFreqsWithoutPattern.put(referenceClass, referenceClassFreq);
			}
			if(otherClassesFreq > 0.0){
				oneVsAllClassFreqsWithoutPattern.put("otherClasses", otherClassesFreq);
			}
			
			
			
			
			double entropySeqsWithPattern = determineEntropy(oneVsAllClassFreqsWithPattern);
			double entropySeqsWithoutPattern = determineEntropy(oneVsAllClassFreqsWithoutPattern);					
			double splitEntropy = freqSeqsWithPattern*entropySeqsWithPattern + (1.0-freqSeqsWithPattern)*entropySeqsWithoutPattern;
			
			if(Double.isNaN(splitEntropy)){
				System.out.println("Nan found!!!");
				System.out.println(classFreqsWithPattern);
				System.out.println(classFreqsWithoutPattern);
				System.out.println(oneVsAllClassFreqsWithPattern);
				System.out.println(oneVsAllClassFreqsWithoutPattern);
				System.exit(1);
			}
			
			oneVsAllGains[i] = (initialEntropy[i] - splitEntropy);
		}

		//long endSubTime = System.currentTimeMillis();
		//totalSubTimeIGCALC = totalSubTimeIGCALC + (endSubTime - initSubTime);
		
		
		
		//long endTime = System.currentTimeMillis();
		//totalTimeIGCALC = totalTimeIGCALC + (endTime - startTime);
		
		return oneVsAllGains;
	}

}
