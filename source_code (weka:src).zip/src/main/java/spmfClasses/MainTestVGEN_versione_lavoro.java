package spmfClasses;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import spmfClasses.AlgoVGEN_versione_lavoro_multiclass;


/**
 * Example of how to use the VGEN algorithm in source code.
 * @author Philippe Fournier-Viger
 */
public class MainTestVGEN_versione_lavoro {

	public static void main(String [] arg) throws IOException{  
		
		/*
		BufferedReader br1 = null;
		FileReader fr1 = null;
		
		BufferedReader br2 = null;
		FileReader fr2 = null;
		
		PrintWriter writer = new PrintWriter("/Users/andreabrunello/Desktop/prova/nuova_codifica_vecchi_delims.csv", "UTF-8");
		fr1 = new FileReader("/Users/andreabrunello/Desktop/prova/dataset_spmf_labeled.txt");
		br1 = new BufferedReader(fr1);
		fr2 = new FileReader("/Users/andreabrunello/Desktop/prova/the-file-name.txt");
		br2 = new BufferedReader(fr2);
		

		String sCurrentLine1;
		String sCurrentLine2;
		
		writer.println("seq,class");

		while ((sCurrentLine1 = br1.readLine()) != null) {
			sCurrentLine2 = br2.readLine();
			writer.println(sCurrentLine2+","+sCurrentLine1.split(",")[1]);
		}
		
		writer.close();
		 */
		
		/*
		BufferedReader br = null;
		FileReader fr = null;

		try {

			PrintWriter writer = new PrintWriter("/Users/andreabrunello/Desktop/NEW_ENC_conv.txt", "UTF-8");
			fr = new FileReader("/Users/andreabrunello/Desktop/NEW_ENC.txt");
			br = new BufferedReader(fr);

			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);
				String stringa = "";
				String[] lineaSplittata = sCurrentLine.split(">");
				for(String elemento : lineaSplittata){
					String parte = elemento;
					if(elemento.equals("0")){
						parte = "2";
					}
					else if(elemento.equals("1")){
						parte = "0";
					}
					else if(elemento.equals("2")){
						parte = "9";
					}
					else if(elemento.equals("4")){
						parte = "6";
					}
					else if(elemento.equals("5")){
						parte = "10";
					}
					else if(elemento.equals("6")){
						parte = "7";
					}
					else if(elemento.equals("7")){
						parte = "11";
					}
					else if(elemento.equals("8")){
						parte = "1";
					}
					else if(elemento.equals("9")){
						parte = "5";
					}
					else if(elemento.equals("11")){
						parte = "8";
					}
					else if(elemento.equals("10")){
						parte = "4";
					}
					stringa = stringa + parte + ">";
				}
				writer.println(stringa.substring(0, stringa.length()-1));
			}
			
			writer.close();

		} catch (IOException e) {

			e.printStackTrace();

		}
		
		System.exit(0);
		
		*/
	
		
		/*
		
		// Parte per testare l'algoritmo VGEN modificato per il DT su un'istanza ad-hoc
		List<int[]> horizontalDatabase = new ArrayList<int[]>();
		String[] tempClasses = {"true", "true", "true", "true", "true", "true", "true", "true", "false", "true", "true", "true", "true", "true", "true", "true", "true", "true", "true", "true", "true", "false", "true", "true", "true", "true", "true", "true", "true", "true", "true", "true", "true"};
		List<String> classesOfInstances = new ArrayList<String>(Arrays.asList(tempClasses));
		horizontalDatabase.add(new int[] {18427, -1, 18547, -1, 18619, -1, 18779, -1, 18831, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18519, -1, 18615, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18551, -1, 18619, -1, 18659, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18619, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18619, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18423, -1, 18427, -1, 18431, -1, 18443, -1, 18547, -1, 18575, -1, 18579, -1, 18599, -1, 18611, -1, 18619, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18619, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18547, -1, 18619, -1, 18643, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18615, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18603, -1, 18619, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18427, -1, 18611, -1, 18619, -1, 18675, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18423, -1, 18427, -1, 18431, -1, 18611, -1, 18615, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18615, -1, 18619, -1, 18695, -1, 18795, -1, 18799, -1, 18847, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18447, -1, 18619, -1, 18779, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18423, -1, 18427, -1, 18431, -1, 18539, -1, 18543, -1, 18611, -1, 18615, -1, 18619, -1, 18627, -1, 18631, -1, 18635, -1, 18639, -1, 18643, -1, 18647, -1, 18651, -1, 18655, -1, 18659, -1, 18663, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18423, -1, 18427, -1, 18431, -1, 18439, -1, 18443, -1, 18447, -1, 18451, -1, 18459, -1, 18539, -1, 18543, -1, 18547, -1, 18551, -1, 18555, -1, 18559, -1, 18563, -1, 18567, -1, 18571, -1, 18583, -1, 18587, -1, 18595, -1, 18599, -1, 18603, -1, 18611, -1, 18615, -1, 18619, -1, 18627, -1, 18631, -1, 18635, -1, 18639, -1, 18643, -1, 18647, -1, 18651, -1, 18655, -1, 18659, -1, 18663, -1, 18671, -1, 18675, -1, 18679, -1, 18683, -1, 18743, -1, 18747, -1, 18751, -1, 18755, -1, 18759, -1, 18763, -1, 18767, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18615, -1, 18619, -1, 18767, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18611, -1, 18619, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18423, -1, 18427, -1, 18431, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {12783, -1, 12787, -1, 18427, -1, 18443, -1, 18447, -1, 18551, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18547, -1, 18615, -1, 18619, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18595, -1, 18615, -1, 18619, -1, 18631, -1, -2});
		horizontalDatabase.add(new int[] {18411, -1, 18427, -1, 18615, -1, 18619, -1, 18675, -1, 18767, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {10335, -1, 18411, -1, 18419, -1, 18427, -1, 18471, -1, 18475, -1, 18483, -1, 18599, -1, 18611, -1, 18619, -1, 18671, -1, 18811, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18427, -1, 18619, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18427, -1, 18615, -1, 18619, -1, 18831, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {12795, -1, 12799, -1, 12803, -1, 12859, -1, 12863, -1, 12867, -1, 12871, -1, 12875, -1, 12879, -1, 12883, -1, 12887, -1, 12891, -1, 12895, -1, 12899, -1, 12903, -1, 18419, -1, 18423, -1, 18427, -1, 18431, -1, 18439, -1, 18443, -1, 18447, -1, 18451, -1, 18459, -1, 18539, -1, 18543, -1, 18547, -1, 18551, -1, 18555, -1, 18559, -1, 18563, -1, 18567, -1, 18571, -1, 18583, -1, 18587, -1, 18595, -1, 18599, -1, 18603, -1, 18611, -1, 18615, -1, 18619, -1, 18627, -1, 18631, -1, 18635, -1, 18639, -1, 18643, -1, 18647, -1, 18651, -1, 18655, -1, 18659, -1, 18663, -1, 18671, -1, 18675, -1, 18679, -1, 18683, -1, 18743, -1, 18747, -1, 18751, -1, 18755, -1, 18759, -1, 18763, -1, 18767, -1, 35149, -1, 35153, -1, 35157, -1, 35161, -1, 35165, -1, 35169, -1, 35177, -1, 35181, -1, 35185, -1, 35189, -1, 35193, -1, 35197, -1, 35201, -1, 35205, -1, 35209, -1, -2});
		horizontalDatabase.add(new int[] {18427, -1, 18459, -1, 18615, -1, 18619, -1, 18767, -1, 18855, -1, -2});
		horizontalDatabase.add(new int[] {18419, -1, 18427, -1, 18611, -1, 18615, -1, 18619, -1, -2});
	
		AlgoVGEN_versione_DT algo_lav_DT = new AlgoVGEN_versione_DT(horizontalDatabase, classesOfInstances);
		algo_lav_DT.runAlgorithm(0.0, 0.01);    
		algo_lav_DT.printStatistics();	
		
		System.exit(0);
		
		*/
		
		
		// Load a sequence database
		String main_path = "/Users/andreabrunello/Dropbox/PhD Andrea - mio/Estrazione_pattern_discriminanti/dataset_pesanti/gazelle/dataset_problematico_sup_1_perc/";
		String input1 = fileToPath(main_path + "dataset_spmf.txt");
		String input2 = fileToPath(main_path + "dataset_spmf_labeled.txt");
		//String input = fileToPath("contextPrefixSpan.txt");
		String output1 = main_path + "output_VGEN_classic.txt";
		String output2 = main_path + "output_VGEN_modded.txt";
		
		Double minsup = 0.01;	//Nel DT, è impostabile dall'utente
		
		// Create an instance of the algorithm 
		AlgoVGEN algo = new AlgoVGEN(); 
		//AlgoVGEN_versione_lavoro algo_lav = new AlgoVGEN_versione_lavoro();
		//AlgoVGEN_versione_lavoro_multiclass algo_lav_multi = new AlgoVGEN_versione_lavoro_multiclass();

		// This optional parameter allows to specify the maximum pattern length:
//		algo.setMaximumPatternLength(4);  // optional
		
		// This optional parameter allows to specify the max gap between two
		// itemsets in a pattern. If set to 1, only patterns of contiguous itemsets
		// will be found (no gap).
		//algo.setMaxGap(1);
		
        // if you set the following parameter to true, the sequence ids of the sequences where
        // each pattern appears will be shown in the result
//		algo.showSequenceIdentifiersInOutput(true);
		
		// execute the algorithm with minsup = 2 sequences  (50 %)
		algo.runAlgorithm(input1, output1, minsup);    
		algo.printStatistics();
		
		//algo_lav.runAlgorithm(input2, output2, minsup);    
		//algo_lav.printStatistics();
		
		//algo_lav_multi.runAlgorithm(input2, output2, minsup);    
		//algo_lav_multi.printStatistics();
	}
	
	public static String fileToPath(String filename) throws UnsupportedEncodingException, MalformedURLException{
		URL url = Paths.get(filename).toUri().toURL();
		//URL url = MainTestVGEN_versione_lavoro.class.getResource(filename);
		return java.net.URLDecoder.decode(url.getPath(),"UTF-8");
	}
}